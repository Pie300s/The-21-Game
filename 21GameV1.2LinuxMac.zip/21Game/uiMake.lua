local uiMake = {}
local lfs = require("lfs")

function uiMake.openUIFile(name)
	local home_dir = os.getenv("HOME")
	local target_dir = home_dir and (home_dir .. "/Documents/21Game/uiData/") or "./"
	local full_path = target_dir .. name

	local file = io.open(full_path, "r")
	if file then
		for line in file:lines() do
			print(line)
		end
		file:close()
	else
		io.write("No UI file was found at ".. full_path .. ", please make one.")
    end
end

return uiMake
