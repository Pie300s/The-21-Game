--The 21 Game
--Programmed by Pie

local uiMake = require("uiMake")
local cards = {2,3,4,5,6,7,8,9}
local hand = {}
local cardSum = 0

--Drawing a random card for hand
function hit()
    local index = math.randomseed(#cards)
    local card = cards[index]

    table.insert(hand, card)
    cardSum = cardSum + card

    print("Card drawn:", card)
    print("Total:", cardSum)
    print()
end

--Win/Lose 
function lose()
    uiMake.openUIFile("lose.txt")
    print("\nYou lost with ".. #hand .." cards in hand.")
    print("\nPress e to exit.")
    local exitKey = io.read()
    if exitKey == "e" then
        os.exit()
    else
        uiMake.openUIFile("error.txt")
    end
end

function win()
    uiMake.openUIFile("win.txt")
    print("\nYou won with ".. #hand .." cards in hand.")
    print("\nPress e to exit.")
    local exitKey = io.read()
    if exitKey == "e" then
        os.exit()
    else
        uiMake.openUIFile("error.txt")
    end
end

--Gameloop
function gameLoop()
    if #hand == 0 then
        for i = 1,2 do
            hit()
        end
    end

    while true do
        uiMake.openUIFile("choice.txt")
        print("")
        local choice = tonumber(io.read())

        if choice == 1 then
            lose()

        elseif choice == 2 then
            hit()

            if cardSum > 21 then
                lose()
            elseif cardSum == 21 then
                win()
            end
        else
            uiMake.openUIFile("error.txt")
        end
    end
end

gameLoop()
