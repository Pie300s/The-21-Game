The rules of the game are:
You pick to give up or hit (draw)
if your hand is bigger than 21
you suck and lose.

DOWNLOAD INSTRUCTIONS:

REQUIRED LUA PACKAGES:
1. luarocks
2. luafilesystem

Extract this to your documents folder